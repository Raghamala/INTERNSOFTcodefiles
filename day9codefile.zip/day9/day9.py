# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

x=pd.read_csv('AAPL Historical Data.csv', usecols=[0,1,2,3])

POH_avg=x[['Price','Open','High']].mean(axis=1)

y=np.arange(1,len(x)+1,1)

plt.plot(y,POH_avg,'r', label='MY FIRST PROJECT')
